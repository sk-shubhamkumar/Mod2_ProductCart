package com.org.repo;

import java.util.List;

import com.org.bean.Product;

public interface IProductRepo {

	boolean save(Product product);

	Product findById(String id);

	List<Product> findAll();

	boolean remove(String id);

	Product updateProduct(String id, Product product);

}