package com.org.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.bean.Product;
import com.org.exception.DuplicateProductIdException;
import com.org.exception.ProductIdNotFoundException;
import com.org.repo.IProductRepo;

@Service("service")
@Transactional
public class ProductServiceImpl implements IProductService {

	@Autowired
	IProductRepo repo;

	public IProductRepo getRepo() {
		return repo;
	}

	public void setRepo(IProductRepo repo) {
		this.repo = repo;
	}

	
	/***********************************************************
	 - Method Name		:	addProduct(Product product)
	 - Input Parameter	:	Product product
	 - Return Type		:	Product
	 - Throws			:	DuplicateProductIdException
	 - Author			: 	Shubham Kumar
	 - Date				:	12-03-2019
	 - Description		:	Add a new product to the database.
	 ***********************************************************/
	
	@Override
	public Product addProduct(Product product) throws DuplicateProductIdException{
		if(repo.save(product)) {
			return repo.findById(product.getId());
		}
		throw new DuplicateProductIdException();
	}
	
	
	/****************************************************************
	 - Method Name		:	findProduct(String id)
	 - Input Parameter	:	String id
	 - Return Type		:	Product
	 - Throws			:	ProductIdNotFoundException
	 - Author			: 	Shubham Kumar
	 - Date				:	12-03-2019
	 - Description		:	Find a product into the database by id.
	 ****************************************************************/

	@Override
	public Product findProduct(String id) throws ProductIdNotFoundException{
		Product result = repo.findById(id);
		if(result == null) {
			throw new ProductIdNotFoundException();
		}
		return result;
	}

	
	/****************************************************************
	 - Method Name		:	updateProduct(String id, Product product)
	 - Input Parameter	:	String id, Product product
	 - Return Type		:	Product
	 - Throws			:	ProductIdNotFoundException
	 - Author			: 	Shubham Kumar
	 - Date				:	12-03-2019
	 - Description		:	Update an existing product by id.
	 ******************************************************************/
	
	@Override
	public Product updateProduct(String id, Product product) throws ProductIdNotFoundException {
		Product result = repo.updateProduct(id,product);
		if(result==null) {
			throw new ProductIdNotFoundException();
		}
		return result;
		
		
	}
	
	
	/**********************************************************************
	 - Method Name		:	getProductList(String id)
	 - Input Parameter	:	String id
	 - Return Type		:	List<Product>
	 - Throws			:	none
	 - Author			: 	Shubham Kumar
	 - Date				:	12-03-2019
	 - Description		:	Show the all product list present in database.
	 **********************************************************************/
	
	@Override
	public List<Product> getProductList(){
		return repo.findAll();
	}

	@Override
	public Product deleteProduct(String id) throws ProductIdNotFoundException{
		Product result = repo.findById(id);
		if(repo.remove(id)) {
			return result;
		}
		throw new ProductIdNotFoundException();
	}
}
