package com.org.service;

import java.util.List;

import com.org.bean.Product;
import com.org.exception.DuplicateProductIdException;
import com.org.exception.ProductIdNotFoundException;

public interface IProductService {

	Product addProduct(Product product) throws DuplicateProductIdException;

	Product findProduct(String id) throws ProductIdNotFoundException;

	Product updateProduct(String id, Product product) throws ProductIdNotFoundException;

	List<Product> getProductList();

	Product deleteProduct(String id) throws ProductIdNotFoundException;

}