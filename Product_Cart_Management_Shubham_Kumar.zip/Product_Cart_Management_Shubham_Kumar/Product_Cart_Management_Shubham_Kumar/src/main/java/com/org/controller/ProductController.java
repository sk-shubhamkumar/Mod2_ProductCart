package com.org.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.org.bean.Product;
import com.org.exception.DuplicateProductIdException;
import com.org.exception.ProductIdNotFoundException;
import com.org.service.IProductService;

@RestController
public class ProductController {
	@Autowired
	IProductService productServ;
	
	
	/****************************************************************************************
	 - URL name			:	/addProduct
	 - Method Type		:	POST
	 - Method			:	addProduct()
	 - Input Parameter	:	Product product
	 - Return Type		:	Product
	 - Throws			:	DuplicateProductIdException
	 - Author			: 	Shubham Kumar
	 - Date				:	12-03-2019
	 - Description		:	Accept the product details in JSON format and save into database.
	 *****************************************************************************************/
	
	@RequestMapping(value="/addProduct", method=RequestMethod.POST, consumes="application/json", produces="application/json")
	public Product addProduct(@RequestBody Product product) throws DuplicateProductIdException {
		product = productServ.addProduct(product);
		return product;
	}
	
	
	/**********************************************************************************
	 - URL name			:	/getProduct/{id}
	 - Method Type		:	GET
	 - Method			:	getProduct()
	 - Input Parameter	:	String id
	 - Return Type		:	Product
	 - Throws			:	ProductIdNotFoundException
	 - Author			: 	Shubham Kumar
	 - Date				:	12-03-2019
	 - Description		:	Get the product details by id in JSON format from database.
	 ***********************************************************************************/

	@RequestMapping(value="/getProduct/{id}", method=RequestMethod.GET, produces="application/json")
	public Product getProduct(@PathVariable String id) throws ProductIdNotFoundException{
		Product product = new Product();
		product = productServ.findProduct(id);
		return product;
	}
	
	
	/********************************************************************************
	 - URL name			:	/Products/{id}
	 - Method Type		:	PUT
	 - Method			:	updateProduct()
	 - Input Parameter	:	String id
	 - Return Type		:	Product
	 - Throws			:	ProductIdNotFoundException
	 - Author			: 	Shubham Kumar
	 - Date				:	12-03-2019
	 - Description		:	Update the product details by id and save into database.
	 *********************************************************************************/
	
	@RequestMapping(value="/products/{id}", method=RequestMethod.PUT, consumes="application/json", produces="application/json")
	public Product updateProduct(@PathVariable String id, @RequestBody Product product) throws ProductIdNotFoundException {
		 Product updatedProduct = productServ.updateProduct(id, product);
		return updatedProduct;
	}
	

	/**********************************************************************************
	 - URL name			:	/products
	 - Method Type		:	GET
	 - Method			:	getAllProducts()
	 - Input Parameter	:	none
	 - Return Type		:	list
	 - Throws			:	none
	 - Author			: 	Shubham Kumar
	 - Date				:	12-03-2019
	 - Description		:	Get all product details in JSON format from database.
	 ***********************************************************************************/
	
	@RequestMapping(value="/products", method=RequestMethod.GET, produces="application/json")
	public List<Product> getAllProducts() {
		List<Product> list = productServ.getProductList();
		return list;
	}
	
	
	/***************************************************************************
	 - URL name			:	/deleteProduct/{id}
	 - Method Type		:	POST
	 - Method			:	deleteProduct()
	 - Input Parameter	:	String id
	 - Return Type		:	Product
	 - Throws			:	ProductIdNotFoundException
	 - Author			: 	Shubham Kumar
	 - Date				:	12-03-2019
	 - Description		:	Delete the product details by id into database.
	 **************************************************************************/
	
	@RequestMapping(value="/deleteProduct/{id}", method=RequestMethod.POST, consumes="application/json", produces="application/json")
	public Product deleteProduct(@PathVariable String id) throws ProductIdNotFoundException{
		Product product = productServ.deleteProduct(id);
		return product;
	}
	
	
	/***************************************************************************
	 - Exception Handle		:	DuplicateProductIdException
	 - Return				:	This product Id already present.
	 - Author				: 	Shubham Kumar
	 - Date					:	12-03-2019
	 - Description			:	Handle Duplicate Product Id Exception.
	 **************************************************************************/
	
	@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "This product Id already present.")
	@ExceptionHandler({ DuplicateProductIdException.class })
	public void handleDuplicateIdException() {}
	
	
	/***************************************************************************
	 - Exception Handle		:	ProductIdNotFoundException
	 - Return				:	This product Id is not present.
	 - Author				: 	Shubham Kumar
	 - Date					:	12-03-2019
	 - Description			:	Handle Product Id Not Found Exception.
	 **************************************************************************/
	
	@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "This product Id is not present.")
	@ExceptionHandler({ ProductIdNotFoundException.class })
	public void handleIdNotFoundException() {}
}