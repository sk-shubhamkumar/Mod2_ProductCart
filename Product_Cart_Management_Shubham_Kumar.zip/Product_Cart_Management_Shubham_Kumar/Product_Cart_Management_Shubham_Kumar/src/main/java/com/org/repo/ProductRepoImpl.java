package com.org.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.org.bean.Product;

@Repository
public class ProductRepoImpl implements IProductRepo {
	
	
	@PersistenceContext
	private EntityManager em;

	public EntityManager getEm() {
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}

	
	/***************************************************************
	 - Method Name		:	save(Product product)
	 - Input Parameter	:	Product product
	 - Return Type		:	boolean
	 - Throws			:	none
	 - Author			: 	Shubham Kumar
	 - Date				:	12-03-2019
	 - Description		:	Save the product details into database.
	 ****************************************************************/
	
	@Override
	public boolean save(Product product) {
		Product result = findById(product.getId());
		if(result==null) {
			em.merge(product);
			return true;
		}
		return false;
	}
	
	
	/**************************************************************************
	 - Method Name		:	findById(String id)
	 - Input Parameter	:	String id
	 - Return Type		:	Product
	 - Throws			:	none
	 - Author			: 	Shubham Kumar
	 - Date				:	12-03-2019
	 - Description		:	Find the product details into database by using id.
	 ***************************************************************************/
	
	@Override
	public Product findById(String id) {
		Product product = em.find(Product.class, id);
		return product;
	}

	
	/**********************************************************************
	 - Method Name		:	updateProduct(String id, Product product)
	 - Input Parameter	:	String id, Product product
	 - Return Type		:	Product
	 - Throws			:	ProductIdNotFoundException
	 - Author			: 	Shubham Kumar
	 - Date				:	12-03-2019
	 - Description		:	Update an existing product into database by id.
	 **********************************************************************/
	
	@Override
	public Product updateProduct(String id, Product product) {
		Product result = em.find(Product.class, id);
		if(result == null) {
			return result;
		}
		em.merge(product);
		return result;
	}

	
	/**************************************************************
	 - Method Name		:	findAll()
	 - Input Parameter	:	none
	 - Return Type		:	List<Product>
	 - Throws			:	none
	 - Author			: 	Shubham Kumar
	 - Date				:	12-03-2019
	 - Description		:	Find all the product present in databse.
	 ***************************************************************/
	
	@Override
	public List<Product> findAll(){
		TypedQuery<Product> query = em.createQuery("select products from Product products", Product.class);
		List<Product> list = query.getResultList();
		return list;
	}

	
	/*********************************************************
	 - Method Name		:	remove(String id)
	 - Input Parameter	:	String id
	 - Return Type		:	boolean
	 - Throws			:	none
	 - Author			: 	Shubham Kumar
	 - Date				:	12-03-2019
	 - Description		:	Remove an existing product by id.
	 *********************************************************/
	
	@Override
	public boolean remove(String id) {
		Product product = em.find(Product.class, id);
		if(product==null) {
			return false;
		}
		em.remove(product);
		em.flush();
		return true;
	}
	
}
