package com.org.Product_Cart_Management_Shubham_Kumar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.org")
@EntityScan("com.org.bean")
public class Product_Cart_Management_Shubham_KumarApplication {

	public static void main(String[] args) {
		SpringApplication.run(Product_Cart_Management_Shubham_KumarApplication.class, args);
	}

}
