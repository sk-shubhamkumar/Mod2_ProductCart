package com.org.exception;

public class ProductIdNotFoundException extends Exception{

	private static final long serialVersionUID = 1L;

}
